-- SETTINGS
BLINKY_PLANT_INTERVAL = 3
NEW_STYLE_WIRES  = true  -- true = new nodebox wires, false = old raillike wires
